/* Regression test: minecart push (forced move route must survive a page change) and idle event patterns ("!" markers). */
#include "../source/game.h"
#include "host.h"
#include <stdio.h>
static PInput in;
static void step(uint32_t held) { host_set_held(held); plat_begin_frame(&in); game_frame(&in); plat_end_frame(); }
static void run(int n, uint32_t h) { for (int i = 0; i < n; i++) step(h); }
int main(void)
{
    host_set_roots("romfs", "tests/hostgfx", "tests/user");
    plat_init(); if (!game_init()) return 1;
    game_begin_new();
    run(2, 0);
    g_interp.running = 0; msg.active = 0; g_fade = 0; g_fade_target = 0; g_scene_request = -1;
    int fails = 0;
    /* --- minecart on map 8 --- */
    player_reserve_transfer(8, 16, 5, 6, 2); player_perform_transfer();
    item_gain(0, 2, 1);                 /* diamond */
    g_needs_refresh = 1; run(3, 0);
    Char *cart = map_event(2);
    printf("cart start x=%d y=%d page=%d\n", cart->x, cart->y, cart->pageIdx);
    step(K_A); run(1, 0);
    run(200, 0);
    printf("cart end x=%d (expected 22) diamonds left=%d forcing=%d\n", cart->x, item_count(0, 2), cart->forcing);
    if (cart->x != 22) { printf("FAIL cart\n"); fails++; }
    /* --- "!" marker: map 8 event 1 at (22,1) uses sheet pattern 0 --- */
    map_unload(); player_reserve_transfer(8, 3, 10, 2, 2); player_perform_transfer(); run(2, 0);
    Char *mk = map_event(1);
    int bad = 0;
    for (int f = 0; f < 600; f++) { step(0); if (mk->pattern != 0) bad++; }
    printf("marker pattern!=0 on %d / 600 frames (sheet %d, origPat %d)\n", bad, mk->sheet, mk->origPat);
    if (bad) { printf("FAIL marker\n"); fails++; }
    printf(fails ? "FAILED\n" : "ALL PASSED\n");
    return fails;
}
