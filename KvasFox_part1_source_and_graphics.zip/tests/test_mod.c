/* Mod menu test: X+Y+SELECT on title, new-game bonuses, editing a save slot. */
#include "../source/game.h"
#include "host.h"
#include <stdio.h>
#include <stdlib.h>
static PInput in;
static void step(uint32_t held) { host_set_held(held); plat_begin_frame(&in); game_frame(&in); plat_end_frame(); }
static void run(int n, uint32_t h) { for (int i = 0; i < n; i++) step(h); }
static void tap(int x, int y) { host_set_touch(true, x, y); step(0); host_set_touch(false, x, y); step(0); }
static void shot(const char *n) { char p[128]; snprintf(p, sizeof p, "tests/out/%s", n); host_dump(p); }
#define CHECK(c) do { if (!(c)) { printf("FAIL: %s (line %d)\n", #c, __LINE__); fails++; } } while (0)
int main(void)
{
    int fails = 0;
    host_set_roots("romfs", "tests/hostgfx", "tests/user");
    plat_init(); remove("tests/user/mod.dat"); remove("tests/user/save1.sav");
    if (!game_init()) return 1;
    g_lang = LANG_EN;
    run(3, 0);
    /* SELECT alone must still switch language (on release) */
    step(K_SELECT); step(0); CHECK(g_lang == LANG_RU); g_lang = LANG_EN;
    /* X+Y+SELECT must NOT switch language and must open the menu */
    step(K_X | K_Y); step(K_X | K_Y | K_SELECT); step(K_X | K_Y); step(0);
    CHECK(mod_active()); CHECK(g_lang == LANG_EN);
    shot("40_mod_main");
    tap(100, 47);                      /* New game bonuses */
    shot("41_mod_loot");
    tap(100, 47);                      /* Extra gold */
    for (int i = 0; i < 3; i++) tap(290, 130);   /* +10000 x3 */
    tap(60, 215);                      /* OK */
    shot("42_mod_gold");
    tap(100, 47 + 22);                 /* Extra start levels */
    tap(290, 130); tap(60, 215);       /* +10 levels */
    tap(100, 47 + 44);                 /* Items */
    shot("43_mod_items");
    tap(100, 47 + 22);                 /* 2nd item (diamond, id 2) */
    tap(216, 130); tap(60, 215);  /* +5 */
    step(K_B); step(0);                /* back to loot */
    step(K_B); step(0);                /* back to main */
    tap(100, 47 + 22 * 4);             /* Close */
    CHECK(!mod_active());
    tap(160, 40);                      /* New game */
    run(2, 0);
    for (int i = 1; i < 9; i++) printf("actor %d valid=%d level=%d\n", i, g.actors[i].valid, g.actors[i].level); printf("party n=%d first=%d\n", g.nparty, g.party[0]);
    printf("new game: gold=%d diamonds=%d lead level=%d\n", g.gold, g.items[2], party_member(0)->level);
    CHECK(g.gold >= 30000); CHECK(g.items[2] >= 5); CHECK(g.actors[1].level >= 13 && g.actors[8].level >= 11);
    /* write a save through the normal path, then edit it with the mod menu */
    save_write(0);
    g_scene_request = SC_TITLE; run(3, 0);
    CHECK(g_scene == SC_TITLE);
    int goldBefore = g.gold;
    step(K_X | K_Y | K_SELECT); step(0);
    CHECK(mod_active());
    tap(100, 47 + 22);                 /* Edit save 1 */
    shot("44_mod_save");
    tap(100, 47);                      /* Gold */
    tap(10 + 0, 130);                  /* -big */
    tap(60, 215);
    tap(100, 47 + 22 * 4);             /* Party levels */
    shot("45_mod_party");
    step(K_B); step(0);
    tap(100, 47 + 22 * 6);             /* SAVE CHANGES */
    shot("46_mod_saved");
    step(K_B); step(0); tap(100, 47 + 22 * 4); CHECK(!mod_active());
    CHECK(save_read(0));
    printf("after edit: gold %d (was %d)\n", g.gold, goldBefore);
    CHECK(g.gold == goldBefore - 10000 || (goldBefore < 10000 && g.gold == 0));
    CHECK(g.items[2] >= 5);
    printf(fails ? "MOD TEST FAILED (%d)\n" : "MOD TEST PASSED\n", fails);
    return fails;
}
