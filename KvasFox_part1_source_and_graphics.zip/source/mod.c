/* mod.c - hidden "Mod menu" on the title screen (hold X + Y + SELECT).
 *
 *   New game bonuses : gold / items / weapons / armor / start level that are added when a NEW game starts
 *                      (stored in /3ds/KvasFox/mod.dat, stay until you reset them).
 *   Edit save slot   : change gold, items, weapons, armor, party levels or heal the party inside an
 *                      existing save file (save1.sav .. save3.sav).
 *
 * Everything works with the touch screen and with the buttons (D-pad move, A select, B back). */
#include "game.h"
#include <stdio.h>
#include <stdlib.h>

#define GOLD_MAX 99999999
#define ITEM_MAX 99

typedef struct {
    int magic;
    int gold, bonusLevel;
    int items[MAX_DB], weapons[MAX_DB], armors[MAX_DB];
} ModLoot;
#define MOD_MAGIC 0x4D4F4401

static ModLoot s_loot;
static int s_loaded;

enum { MS_OFF, MS_MAIN, MS_LOOT, MS_SAVE, MS_PICK, MS_PARTY, MS_NUM };
enum { NK_GOLD, NK_ITEM, NK_LEVEL, NK_BONUS };

static int s_state, s_prev;          /* current state; state to return to from the number editor */
static int s_mode;                   /* 0 = new-game bonuses, 1 = editing a save slot */
static int s_slot;
static int s_cat;                    /* 0 items, 1 weapons, 2 armors */
static int s_ids[LIST_MAX];          /* list row -> database id */
static UiList s_list;
static char s_msg[80]; static int s_msg_t;
static char s_head[80];

static struct { int kind, a, b, val, min, max, st1, st2, st3; char label[80]; } s_num;
static int s_hold_l, s_hold_r, s_hold_u, s_hold_d;

static const char *T(const char *en, const char *ru) { return g_lang == LANG_RU ? ru : en; }

/* ----------------------------------------------------------------------------- persistence */
static void loot_load(void)
{
    s_loaded = 1;
    memset(&s_loot, 0, sizeof s_loot);
    FILE *f = plat_open_user("mod.dat", false);
    if (!f) return;
    static ModLoot tmp;
    if (fread(&tmp, sizeof tmp, 1, f) == 1 && tmp.magic == MOD_MAGIC) s_loot = tmp;
    fclose(f);
}
static void loot_save(void)
{
    FILE *f = plat_open_user("mod.dat", true);
    if (!f) return;
    s_loot.magic = MOD_MAGIC;
    fwrite(&s_loot, sizeof s_loot, 1, f);
    fclose(f);
}
static bool loot_any(void)
{
    if (!s_loaded) loot_load();
    if (s_loot.gold || s_loot.bonusLevel) return true;
    for (int i = 0; i < MAX_DB; i++) if (s_loot.items[i] || s_loot.weapons[i] || s_loot.armors[i]) return true;
    return false;
}
bool mod_loot_enabled(void) { return loot_any(); }

static void set_level(Battler *b, int target)
{
    int cid = db.actors[b->id].classId;
    target = clampi(target, 1, actor_max_level(b));
    while (b->level < target) actor_level_up(b);      /* also learns the skills of those levels */
    b->level = target;
    b->exp = actor_exp_for_level(cid, target);
    b_set_hp(b, b->hp); b_gain_mp(b, 0);
}

/* called by game_begin_new() right after game_new() */
void mod_apply_new_game(void)
{
    if (!s_loaded) loot_load();
    g.gold = clampi(g.gold + s_loot.gold, 0, GOLD_MAX);
    for (int i = 1; i < MAX_DB; i++) {
        g.items[i] = clampi(g.items[i] + s_loot.items[i], 0, ITEM_MAX);
        g.weapons[i] = clampi(g.weapons[i] + s_loot.weapons[i], 0, ITEM_MAX);
        g.armors[i] = clampi(g.armors[i] + s_loot.armors[i], 0, ITEM_MAX);
    }
    if (s_loot.bonusLevel > 0)             /* every actor, because the story swaps / adds party members */
        for (int id = 1; id < db.nactors && id < ACTOR_MAX; id++) {
            Battler *b = actor_get(id);
            if (!b) continue;
            set_level(b, b->level + s_loot.bonusLevel);
            b_recover_all(b);
        }
}

/* ----------------------------------------------------------------------------- helpers */
static int *gold_ptr(void) { return s_mode == 0 ? &s_loot.gold : &g.gold; }
static int *cnt_ptr(int cat, int id)
{
    if (s_mode == 0) return cat == 0 ? &s_loot.items[id] : (cat == 1 ? &s_loot.weapons[id] : &s_loot.armors[id]);
    return cat == 0 ? &g.items[id] : (cat == 1 ? &g.weapons[id] : &g.armors[id]);
}
static const char *cat_name(int cat)
{
    return cat == 0 ? T("Items", "Предметы") : (cat == 1 ? T("Weapons", "Оружие") : T("Armor", "Броня"));
}
static void say(const char *m) { snprintf(s_msg, sizeof s_msg, "%s", m); s_msg_t = 150; }

static void list_reset(void) { ui_list_init(&s_list, 10, 36, 300, 158, 22); }

static void rebuild(void)
{
    int keepCursor = s_list.cursor, keepScroll = s_list.scroll;
    list_reset();
    char a[96], b[40];
    switch (s_state) {
        case MS_MAIN:
            snprintf(s_head, sizeof s_head, "%s", T("MOD MENU", "МОД-МЕНЮ"));
            ui_list_add(&s_list, T("New game bonuses", "Бонусы новой игры"), loot_any() ? "ON" : "", true);
            for (int i = 0; i < NSLOTS; i++) {
                char info[96];
                bool has = save_info(i, info, sizeof info);
                snprintf(a, sizeof a, T("Edit save %d: %s", "Сохранение %d: %s"), i + 1, has ? info : T("empty", "пусто"));
                ui_list_add(&s_list, a, "", has);
            }
            ui_list_add(&s_list, T("Close", "Закрыть"), "", true);
            break;
        case MS_LOOT:
            snprintf(s_head, sizeof s_head, "%s", T("NEW GAME BONUSES", "БОНУСЫ НОВОЙ ИГРЫ"));
            snprintf(b, sizeof b, "+%d", s_loot.gold);          ui_list_add(&s_list, T("Extra gold", "Доп. деньги"), b, true);
            snprintf(b, sizeof b, "+%d", s_loot.bonusLevel);    ui_list_add(&s_list, T("Extra levels (all heroes)", "Доп. уровни (всем героям)"), b, true);
            ui_list_add(&s_list, cat_name(0), "", true);
            ui_list_add(&s_list, cat_name(1), "", true);
            ui_list_add(&s_list, cat_name(2), "", true);
            ui_list_add(&s_list, T("Reset all bonuses", "Сбросить все бонусы"), "", true);
            break;
        case MS_SAVE:
            snprintf(s_head, sizeof s_head, T("EDIT SAVE %d", "СОХРАНЕНИЕ %d"), s_slot + 1);
            snprintf(b, sizeof b, "%d", g.gold);                ui_list_add(&s_list, T("Gold", "Деньги"), b, true);
            ui_list_add(&s_list, cat_name(0), "", true);
            ui_list_add(&s_list, cat_name(1), "", true);
            ui_list_add(&s_list, cat_name(2), "", true);
            ui_list_add(&s_list, T("Party levels", "Уровни отряда"), "", g.nparty > 0);
            ui_list_add(&s_list, T("Heal whole party", "Вылечить отряд"), "", g.nparty > 0);
            ui_list_add(&s_list, T(">> SAVE CHANGES <<", ">> СОХРАНИТЬ <<"), "", true);
            break;
        case MS_PICK: {
            snprintf(s_head, sizeof s_head, "%s", cat_name(s_cat));
            int n = s_cat == 0 ? db.nitems : (s_cat == 1 ? db.nweapons : db.narmors);
            int rows = 0;
            for (int id = 1; id < n && id < MAX_DB && rows < LIST_MAX; id++) {
                int ex, nm;
                if (s_cat == 0) { ex = db.items[id].exists; nm = db.items[id].name; }
                else if (s_cat == 1) { ex = db.weapons[id].exists; nm = db.weapons[id].name; }
                else { ex = db.armors[id].exists; nm = db.armors[id].name; }
                const char *name = tx(nm);
                if (!ex || !name[0]) continue;
                int c = *cnt_ptr(s_cat, id);
                snprintf(b, sizeof b, c ? "x%d" : "-", c);
                bool header = name[0] == '-' && name[1] == '-';
                ui_list_add(&s_list, name, header ? "" : b, !header);
                s_ids[rows++] = id;
            }
            break;
        }
        case MS_PARTY:
            snprintf(s_head, sizeof s_head, "%s", T("PARTY LEVELS", "УРОВНИ ОТРЯДА"));
            for (int i = 0; i < g.nparty; i++) {
                Battler *bt = party_member(i);
                if (!bt) continue;
                snprintf(b, sizeof b, "%s%d / %d", ui_s(S_LV), bt->level, actor_max_level(bt));
                ui_list_add(&s_list, b_name(bt), b, true);
            }
            break;
        default: break;
    }
    if (s_list.n > 0) {
        s_list.cursor = clampi(keepCursor, 0, s_list.n - 1);
        s_list.scroll = keepScroll;
    }
}

static void go(int st, bool fresh)
{
    s_state = st;
    if (fresh) { list_reset(); }
    rebuild();
}

static void open_num(int kind, int a, int b, int val, int mn, int mx, int s1, int s2, int s3, const char *label)
{
    s_num.kind = kind; s_num.a = a; s_num.b = b; s_num.val = clampi(val, mn, mx); s_num.min = mn; s_num.max = mx;
    s_num.st1 = s1; s_num.st2 = s2; s_num.st3 = s3;
    snprintf(s_num.label, sizeof s_num.label, "%s", label);
    s_prev = s_state; s_state = MS_NUM;
    s_hold_l = s_hold_r = s_hold_u = s_hold_d = 0;
}

static void num_apply(void)
{
    switch (s_num.kind) {
        case NK_GOLD: *gold_ptr() = s_num.val; break;
        case NK_ITEM: *cnt_ptr(s_num.a, s_num.b) = s_num.val; break;
        case NK_BONUS: s_loot.bonusLevel = s_num.val; break;
        case NK_LEVEL: { Battler *bt = party_member(s_num.a); if (bt) set_level(bt, s_num.val); break; }
    }
    if (s_mode == 0) loot_save();
}

/* ----------------------------------------------------------------------------- public API */
bool mod_active(void) { return s_state != MS_OFF; }

void mod_open(void)
{
    if (!s_loaded) loot_load();
    s_mode = 0; s_msg_t = 0;
    go(MS_MAIN, true);
}

static void close_menu(void) { s_state = MS_OFF; s_msg_t = 0; }

/* geometry of the number editor */
#define NB_X(i) (8 + (i) * 52)
static bool num_hit(int i) { return ui_tap(NB_X(i), 114, 48, 34); }

static void num_update(void)
{
    int stepL = 0;
    s_hold_l = (g_in.held & K_LEFT) ? s_hold_l + 1 : 0;
    s_hold_r = (g_in.held & K_RIGHT) ? s_hold_r + 1 : 0;
    s_hold_u = (g_in.held & K_UP) ? s_hold_u + 1 : 0;
    s_hold_d = (g_in.held & K_DOWN) ? s_hold_d + 1 : 0;
#define REP(h) ((h) == 1 || ((h) > 20 && (h) % 3 == 0))
    if (REP(s_hold_l)) stepL -= s_num.st1;
    if (REP(s_hold_r)) stepL += s_num.st1;
    if (REP(s_hold_u)) stepL += s_num.st2;
    if (REP(s_hold_d)) stepL -= s_num.st2;
#undef REP
    if (g_in.down & K_L) stepL -= s_num.st3;
    if (g_in.down & K_R) stepL += s_num.st3;
    if (num_hit(0)) stepL -= s_num.st3;
    if (num_hit(1)) stepL -= s_num.st2;
    if (num_hit(2)) stepL -= s_num.st1;
    if (num_hit(3)) stepL += s_num.st1;
    if (num_hit(4)) stepL += s_num.st2;
    if (num_hit(5)) stepL += s_num.st3;
    if (stepL) { s_num.val = clampi(s_num.val + stepL, s_num.min, s_num.max); audio_sys(SND_CURSOR); }
    if (ui_tap(8, 154, 150, 30)) { s_num.val = s_num.min; audio_sys(SND_CURSOR); }
    if (ui_tap(162, 154, 150, 30)) { s_num.val = s_num.max; audio_sys(SND_CURSOR); }
    if ((g_in.down & K_A) || ui_tap(20, 198, 130, 34)) {
        num_apply(); audio_sys(SND_OK);
        s_state = s_prev; rebuild();
        return;
    }
    if ((g_in.down & K_B) || ui_tap(170, 198, 130, 34)) {
        audio_sys(SND_CANCEL); s_state = s_prev; rebuild();
    }
}

static void back_from(void)
{
    audio_sys(SND_CANCEL);
    switch (s_state) {
        case MS_MAIN: close_menu(); break;
        case MS_LOOT: go(MS_MAIN, true); break;
        case MS_SAVE: go(MS_MAIN, true); break;      /* leaving without "save changes" discards the edits */
        case MS_PICK: case MS_PARTY: s_state = (s_mode == 0) ? MS_LOOT : MS_SAVE; rebuild(); break;
    }
}

static void cat_pick(int cat) { s_cat = cat; go(MS_PICK, true); }

void mod_update(void)
{
    if (s_msg_t > 0) s_msg_t--;
    if (s_state == MS_NUM) { num_update(); return; }
    int r = ui_list_update(&s_list);
    if (r == -1 || ui_tap(220, 200, 90, 30)) { back_from(); return; }
    if (r < 0) return;
    audio_sys(SND_OK);
    switch (s_state) {
        case MS_MAIN:
            if (r == 0) { s_mode = 0; go(MS_LOOT, true); }
            else if (r >= 1 && r <= NSLOTS) {
                if (save_read(r - 1)) { s_mode = 1; s_slot = r - 1; go(MS_SAVE, true); }
                else say(T("Cannot read this save", "Не удалось прочитать сохранение"));
            } else close_menu();
            break;
        case MS_LOOT:
            if (r == 0) open_num(NK_GOLD, 0, 0, s_loot.gold, 0, GOLD_MAX, 1, 100, 10000, T("Extra gold", "Доп. деньги"));
            else if (r == 1) open_num(NK_BONUS, 0, 0, s_loot.bonusLevel, 0, 98, 1, 5, 10, T("Extra start levels", "Доп. уровни"));
            else if (r >= 2 && r <= 4) cat_pick(r - 2);
            else { memset(&s_loot, 0, sizeof s_loot); loot_save(); rebuild(); say(T("Bonuses reset", "Бонусы сброшены")); }
            break;
        case MS_SAVE:
            if (r == 0) open_num(NK_GOLD, 0, 0, g.gold, 0, GOLD_MAX, 1, 100, 10000, T("Gold", "Деньги"));
            else if (r >= 1 && r <= 3) cat_pick(r - 1);
            else if (r == 4) go(MS_PARTY, true);
            else if (r == 5) {
                for (int i = 0; i < g.nparty; i++) { Battler *bt = party_member(i); if (bt) b_recover_all(bt); }
                say(T("Party healed (not saved yet)", "Отряд вылечен (ещё не сохранено)"));
            } else {
                if (save_patch_state(s_slot)) { audio_sys(SND_SAVE); say(T("Save file updated!", "Файл сохранения обновлён!")); }
                else say(T("Writing the save failed", "Не удалось записать сохранение"));
            }
            break;
        case MS_PICK: {
            int id = s_ids[r];
            int mx = ITEM_MAX;
            open_num(NK_ITEM, s_cat, id, *cnt_ptr(s_cat, id), 0, mx, 1, 5, 10, s_list.label[r]);
            break;
        }
        case MS_PARTY: {
            Battler *bt = party_member(r);
            if (bt) open_num(NK_LEVEL, r, 0, bt->level, 1, actor_max_level(bt), 1, 5, 10, b_name(bt));
            break;
        }
    }
}

/* ----------------------------------------------------------------------------- drawing */
static void draw_top(void)
{
    plat_target(0);
    plat_rect(0, 0, SCR_W, SCR_H, RGBA(8, 8, 22, 255));
    ui_text_centered("K V A S   F O X   -   M O D", 200, 26, 0.8f, RGBA(255, 220, 90, 255));
    const char *l1 = s_mode == 0 ? T("New game bonuses are added when you press New Game.", "Бонусы добавляются при нажатии «Новая игра».")
                                 : T("Editing a save file directly on the SD card.", "Прямое редактирование файла сохранения.");
    ui_text_centered(l1, 200, 80, 0.5f, RGBA(220, 225, 255, 255));
    ui_text_centered(T("Touch screen or D-Pad + A / B to navigate.", "Сенсорный экран или крестовина + A / B."), 200, 100, 0.5f, RGBA(180, 190, 230, 255));
    char t[96];
    if (s_state == MS_SAVE || s_mode == 0) {
        snprintf(t, sizeof t, "%s: %d", T("Gold", "Деньги"), s_mode == 0 ? s_loot.gold : g.gold);
        ui_text_centered(t, 200, 140, 0.6f, RGBA(255, 255, 255, 255));
    }
    if (s_state == MS_NUM) ui_text_centered(s_num.label, 200, 170, 0.7f, RGBA(150, 255, 170, 255));
    if (s_msg_t > 0) ui_text_centered(s_msg, 200, 205, 0.55f, RGBA(150, 255, 150, 255));
}

static void num_draw(void)
{
    ui_text_centered(s_num.label, 160, 8, 0.55f, RGBA(255, 235, 150, 255));
    char t[48]; snprintf(t, sizeof t, "%d", s_num.val);
    ui_text_centered(t, 160, 44, 1.1f, RGBA(255, 255, 255, 255));
    snprintf(t, sizeof t, "%d  -  %d", s_num.min, s_num.max);
    ui_text_centered(t, 160, 92, 0.4f, RGBA(160, 170, 210, 255));
    char lb[6][12];
    snprintf(lb[0], 12, "-%d", s_num.st3); snprintf(lb[1], 12, "-%d", s_num.st2); snprintf(lb[2], 12, "-%d", s_num.st1);
    snprintf(lb[3], 12, "+%d", s_num.st1); snprintf(lb[4], 12, "+%d", s_num.st2); snprintf(lb[5], 12, "+%d", s_num.st3);
    for (int i = 0; i < 6; i++) ui_button(NB_X(i), 114, 48, 34, lb[i], true, NULL);
    ui_button(8, 154, 150, 30, T("Minimum", "Минимум"), true, NULL);
    ui_button(162, 154, 150, 30, T("Maximum", "Максимум"), true, NULL);
    ui_button(20, 198, 130, 34, "OK", true, NULL);
    ui_button(170, 198, 130, 34, T("Cancel", "Отмена"), true, NULL);
}

void mod_draw(void)
{
    draw_top();
    plat_target(1);
    plat_rect(0, 0, BSCR_W, BSCR_H, RGBA(18, 18, 34, 255));
    if (s_state == MS_NUM) { num_draw(); return; }
    ui_text_centered(s_head, 160, 10, 0.55f, RGBA(255, 235, 150, 255));
    ui_list_draw(&s_list);
    ui_button(220, 200, 90, 30, s_state == MS_MAIN ? T("Close", "Закрыть") : ui_s(S_BACK), true, NULL);
    if (s_msg_t > 0) plat_text(s_msg, 10, 206, 0.42f, RGBA(150, 255, 150, 255));
}
